import xgboost as xgb
from xgboost import plot_importance
from matplotlib import pyplot as plt
from sklearn.metrics import mean_squared_error as MSE
from sklearn.metrics import mean_absolute_percentage_error

from sklearn.model_selection import train_test_split
import numpy as np
from sklearn.multioutput import MultiOutputRegressor
from sklearn.metrics import r2_score
import joblib
import pandas as pd
#1. load dataset
from pandas import read_csv

dataset=read_csv(r"C:\Users\zhouxin\Desktop\xgboost-MOO\data.csv")
values = dataset.values
Featurenum=5
targetnum=2
X= values[:,0:Featurenum]    
y = values[:,Featurenum:Featurenum+targetnum]


# Seperate

X_train, X_test, y_train, y_test = train_test_split(
    X, y, train_size=0.9, random_state=4)

# Params Preparing
xgb_params = {'learning_rate': 0.05, 
              'n_estimators': 100, 
              'max_depth': 5, 
              'min_child_weight': 1, 
              'seed': 0, 
              'subsample': 0.8, 
              'colsample_bytree': 0.8, 
              'gamma': 0, 
              'reg_alpha': 0,
              'reg_lambda': 1}

# Train XGBMultiOutputRegressor
xgb_multirf = MultiOutputRegressor(xgb.XGBRegressor(
                                            objective='reg:squarederror',
                                            **xgb_params)).fit(X_train, y_train)

# Predict on new data
y_multirf = xgb_multirf.predict(X_test)
y_multirf1 = xgb_multirf.predict(X_train)
#保存数据集
df1 = pd.DataFrame(y_multirf)
df1.to_excel('y_test_predict.xlsx', index=False)
df2 = pd.DataFrame(y_test)
df2.to_excel(' y_test.xlsx', index=False)

df3 = pd.DataFrame(y_multirf1)
df3.to_excel('y_train_predict.xlsx', index=False)
df4 = pd.DataFrame(y_train)
df4.to_excel('y_train.xlsx', index=False)


# Predict on train data
y_train_multirf = xgb_multirf.predict(X_train)
joblib.dump(xgb_multirf, 'mode.joblib' ) 

#重要性
#问题出在MultiOutputRegressor上，因为如果是单标签的常规写法不会出现任何问题。
#解决这个方案的方法就是不直接使用multi_xgb这个封装模型
#而是用multi_xgb.estimators_[0] ,i是模型个数来，作为其中标准的xgboost模型
#从而正常输出importance统计。

plot_importance(xgb_multirf.estimators_[0])
plot_importance(xgb_multirf.estimators_[1])

plt.title('Xgboost Feature Importance')
#plt.show()

Import = xgb_multirf.estimators_[0]
    

# RMSE&r2&Importance
for f in range(targetnum): 
    rf_text_rmse = np.sqrt(MSE(y_train[:, f],y_multirf1[:, f]))
    r2_text = r2_score(y_train[:, f],y_multirf1[:, f])
    mape = mean_absolute_percentage_error(y_train[:, f],y_multirf1[:, f])
    print("xgb在训练集上的RMSE为: %.9f" % rf_text_rmse)
    print("xgb在训练集上的r2为: %.5f" %r2_text)
    print("xgb在训练集上的MAPE为: %.5f" %mape)


for f in range(targetnum): 
    rf_text_rmse = np.sqrt(MSE(y_test[:, f],y_multirf[:, f]))
    r2_text = r2_score(y_test[:, f],y_multirf[:, f])
    mape = mean_absolute_percentage_error(y_test[:, f],y_multirf[:, f])
    print("xgb在测试集上的RMSE为: %.9f" % rf_text_rmse)
    print("xgb在测试集上的r2为: %.5f" %r2_text)
    print("xgb在测试集上的MAPE为: %.5f" %mape)
    

#Plot results 
for f in range(targetnum): 
    plt.plot(y_test[:, f],y_multirf[:, f],'*')
    plt.show()
   