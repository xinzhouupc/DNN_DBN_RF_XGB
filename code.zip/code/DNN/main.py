import pandas as pd
import numpy as np
import torch.nn.functional as F
import torch.nn as nn
from torchsummary import summary
from sklearn.preprocessing import StandardScaler
import joblib
import matplotlib.pyplot as plt
import torch
from tqdm import tqdm
import json
import os
import shap
from sklearn.metrics import r2_score
from sklearn.metrics import mean_squared_error as MSE
from sklearn.metrics import mean_absolute_percentage_error
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"
																											

###############可调整参数#######################
#输入属性
inCols = ['f1', 'f2', 'f3',  'f4', 'f5',]					

#输出属性
outCols  = ['y1', 'y2']
#测试比例
testRate = 0.1
#神经网络层数
layerDim = 30
#神经网络每层节点数
nodeDim = 30
#神经网络迭代次数
epochs = 200
#神经网络学习率
lr = 4e-3
##############################################







#搭建神经网络
class FcBlock(nn.Module):
    def __init__(self,inDim,outDim):
        '''
        一个全连接块
        :param inDim: 输入属性数
        :param outDim: 输出属性数
        '''
        super(FcBlock, self).__init__()
        self.fc = nn.Linear(inDim,outDim)
        self.bn = nn.BatchNorm1d(outDim)
        self.act = nn.PReLU()

    def forward(self,x):
        x = self.fc(x)
        x = self.bn(x)
        x = self.act(x)
        return x

class DNN(nn.Module):
    def __init__(self,inDim,outDim,layerDim=3,nodeDim=100):
        '''
        一个DNN网络
        :param inDim: 输入属性数
        :param outDim: 输出属性数
        :param layerDim: 层数
        :param nodeDim: 每层节点数
        '''
        super(DNN, self).__init__()
        #输入层
        self.fc1 = FcBlock(inDim,nodeDim)
        #中间层
        self.fcList = nn.ModuleList([FcBlock(nodeDim,nodeDim) for i in range(layerDim-2)])
        #输出层
        self.fcn = FcBlock(nodeDim,outDim)

    def forward(self,x):
        x = self.fc1(x)
        for fc in self.fcList:
            x = fc(x)
        x = self.fcn(x)
        return x

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
dnn = DNN(len(inCols),len(outCols),layerDim,nodeDim)
dnn.to(device)
summary(dnn, input_size=(len(inCols),))
dnn.cpu()
    

if __name__ == "__main__":
    #读取数据
    data = pd.read_excel("data.xlsx")
    data = data.sample(frac=1.0)#打乱数据
    data = data.dropna()#删除空值
    
    #预处理数据 比如将字符串转为数字
    colDict = {}
    for col in data.columns:
        try:
            data[col] = data[col].astype(np.float64)
        except:
            data[col],index = pd.factorize(data[col])
            colDict[col] = index.tolist()
    with open("Static/colDict.json","w") as f:
        f.write(json.dumps(colDict))
    
    #数据标准化
    xScaler = StandardScaler().fit(data[inCols])
    yScaler = StandardScaler().fit(data[outCols])
    data[inCols] = xScaler.transform(data[inCols].values).reshape(-1,len(inCols)).tolist()
    data[outCols] = yScaler.transform(data[outCols].values).reshape(-1,len(outCols)).tolist()
    joblib.dump(xScaler, "Static/xScaler.pkl")
    joblib.dump(yScaler, "Static/yScaler.pkl")
    
    #切割训练测试集
    index = int(data.shape[0]*testRate)
    testData = data.iloc[:index].copy()
    trainData = data.iloc[index:].copy()
    print("训练样本%d个"%trainData.shape[0])
    print("测试样本%d个"%testData.shape[0])
    xTest = testData[inCols]
    yTest = testData[outCols]
    xTrain = trainData[inCols]
    yTrain = trainData[outCols]
    
    ##########输出
    yTrain1 = yScaler.inverse_transform(yTrain)#数据归一化还原
    df2 = pd.DataFrame(yTrain1)
    df2.to_excel('yTrain.xlsx', index=False)
    yTest1 = yScaler.inverse_transform(yTest)#数据归一化还原
    df2 = pd.DataFrame(yTest1)
    df2.to_excel('yTest.xlsx', index=False)
    ###########
    
    #训练和测试神经网络
    criterion = nn.MSELoss()
    optimizer = torch.optim.Adam(dnn.parameters(), lr=lr)
    bestLoss = 1e+10#最佳测试损失
    history = {"epoch":[],"train_loss":[],"test_loss":[]}
    bar = tqdm(range(epochs))
    for epoch in bar:
        #训练部分
        dnn.train()
        x = torch.FloatTensor(xTrain.values)
        y = torch.FloatTensor(yTrain.values)
        yPred = dnn(x)
        loss = criterion(yPred, y)
        loss.backward()
        optimizer.step()
        optimizer.zero_grad()
        trainLoss = loss.detach().numpy()
        
        #######输出训练集预测
        
        yTrainPredict = dnn(x).detach().numpy().reshape(-1,len(outCols))
        yTrainPredict = yScaler.inverse_transform(yTrainPredict)#数据归一化还原
        df1 = pd.DataFrame(yTrainPredict)
        df1.to_excel('yTrainPredict.xlsx', index=False)
        #######输出训练集预测
        
        
        
        
        #测试部分
        dnn.eval()
        x = torch.FloatTensor(xTest.values)
        y = torch.FloatTensor(yTest.values)
        yPred = dnn(x)
        loss = criterion(yPred, y)
        testLoss = loss.detach().numpy()
        #######输出测试集预测
        
        yTestPredict = dnn(x).detach().numpy().reshape(-1,len(outCols))
        yTestPredict = yScaler.inverse_transform(yTestPredict)#数据归一化还原
        df1 = pd.DataFrame(yTestPredict)
        df1.to_excel('yTestPredict.xlsx', index=False)
        #######输出测试集预测
    
        bar.set_description("train_loss:%.3f test_loss:%.3f best_test_loss:%.3f"%(trainLoss,testLoss,bestLoss))
        history["epoch"].append(epoch)
        history["train_loss"].append(trainLoss)
        history["test_loss"].append(testLoss)
    
        #保存最佳模型
        if testLoss<bestLoss:
            bestLoss = testLoss
            torch.save(dnn.state_dict(),'Static/best.pth')
    
    #保存训练过程
    history = pd.DataFrame(history)
    history.to_excel("训练过程.xlsx",index=False)
    
    #保存预测值
    dnn.load_state_dict(torch.load('Static/best.pth'))
    x = torch.FloatTensor(xTest.values)
    yPred = dnn(x).detach().numpy().reshape(-1,len(outCols))
    yPred = yScaler.inverse_transform(yPred)#数据归一化还原
    cols = [col+" 预测值" for col in outCols]
    testData[cols] = yPred.tolist()
    saveCols = []
    for col in outCols:
        saveCols.append(col)
        saveCols.append(col+" 预测值")
    testData[outCols] = yScaler.inverse_transform(testData[outCols].values).reshape(-1,len(outCols)).tolist()
    testData.to_excel("测试结果.xlsx",index=False,columns=saveCols)
    
    #可视化
    # fig,ax = plt.subplots(1,1)
    # ax.plot(history["epoch"],history["train_loss"],label="train_loss")
    # #ax.plot(history["epoch"],history["test_loss"],label="test_loss")
    # #ax.legend()
    # ax.set_xlabel("epoch")
    # ax.set_ylabel("loss")
    # fig.savefig("训练过程.png",dpi=250)
    
    #shap解释 Class 0代表第一个因变量；Class n代表第n个因变量；
    # compute SHAP values
    explainer = shap.DeepExplainer(dnn,x) 
    #分析所有
    #shap_values = explainer.shap_values(x)
    features = x[:20,] # 只分析前20个样本
    shap_values = explainer.shap_values(features)
    
    plt.figure(dpi=1200)#高清照片输出
    #######横纵坐标轴
    plt.xlabel('', font={'family':'Arial', 'size':16})
    plt.xticks(fontproperties = 'Arial', size = 12)
    plt.ylabel('', font={'family':'Arial', 'size':16})
    plt.yticks(fontproperties = 'Arial', size = 12)
    shap_plt=shap.summary_plot(shap_values, x)
    
    print("最佳测试集损失:%.4f"%bestLoss)
    # RMSE&r2&Importance
    for f in range(2): 
      dnn_text_rmse = np.sqrt(MSE(yTrain1[:, f],yTrainPredict[:, f]))
      dnn_r2_text = r2_score(yTrain1[:, f],yTrainPredict[:, f])
      dnn_mape = mean_absolute_percentage_error(yTrain1[:, f],yTrainPredict[:, f])
      print("dnn在训练集上的RMSE为: %.9f" % dnn_text_rmse)
      print("dnn在训练集上的r2为: %.5f" %dnn_r2_text)
      print("dnn在训练集上的MAPE为: %.5f" %dnn_mape)

    print("-----------------------------------------------------")
    
    for f in range(2): 
      dnn_text_rmse = np.sqrt(MSE(yTest1[:, f],yTestPredict[:, f]))
      dnn_r2_text = r2_score(yTest1[:, f],yTestPredict[:, f])
      dnn_mape = mean_absolute_percentage_error(yTest1[:, f],yTestPredict[:, f])
      print("dnn在训练集上的RMSE为: %.9f" % dnn_text_rmse)
      print("dnn在训练集上的r2为: %.5f" %dnn_r2_text)
      print("dnn在训练集上的MAPE为: %.5f" %dnn_mape)