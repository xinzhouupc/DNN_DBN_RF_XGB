from sklearn.neural_network import BernoulliRBM
import torch.nn as nn
import torch.nn.functional as F
import torch
import numpy as np
import os
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"
device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')#使用GPU CPU

def data2numpy(data):
    '''张量转为CPU的numpy类型'''
    try:
        return data.detach().cpu().numpy()
    except:
        return data

#搭建神经网络
class FcBlock(nn.Module):
    def __init__(self,inDim,outDim):
        '''
        一个全连接块
        :param inDim: 输入属性数
        :param outDim: 输出属性数
        '''
        super(FcBlock, self).__init__()
        self.fc = nn.Linear(inDim,outDim)
        self.bn = nn.BatchNorm1d(outDim)
        self.act = nn.PReLU()

    def forward(self,x):
        x = self.fc(x)
        x = self.bn(x)
        x = self.act(x)
        return x

class DNN(nn.Module):
    def __init__(self,inDim,middleDims):
        '''
        动态生成DNN网络
        :param inDim: 输入维数
        :param middleDims: 中间层+输出层维数
        '''
        super(DNN, self).__init__()
        inDim = int(inDim)
        middleDims = [int(n) for n in middleDims]
        self.fcLayers = []
        lastDim = inDim
        for i,num in enumerate(middleDims):
            fc = FcBlock(lastDim,num)
            lastDim = num
            self.fcLayers.append(fc)
        self.fcLayers = nn.ModuleList(self.fcLayers)

    def forward(self,x):
        for layer in self.fcLayers:
            x = layer(x)
        return x


class DBN(nn.Module):
    def __init__(self,inDim,middleDims,epochs=100,lr=1e-4):
        ''''''
        super(DBN, self).__init__()
        inDim = int(inDim)
        middleDims = [int(n) for n in middleDims]
        self.middleDims = middleDims
        self.epochs = epochs
        self.lr = lr
        self.buildRBM()
        self.fc1 = nn.Linear(inDim,middleDims[0])
        self.relu1 = nn.PReLU()
        self.fc2 = nn.Linear(middleDims[0],middleDims[1])
        self.relu2 = nn.PReLU()
        self.fc3 = FcBlock(middleDims[1],middleDims[2])

    def buildRBM(self):
        '''建立多个RBM层'''
        self.rbms = []
        for i,dim in enumerate(self.middleDims[:-1]):
            if i>0:
                self.epochs = self.epochs*2
            rbm = BernoulliRBM(n_components=dim, learning_rate=self.lr, batch_size=10000, n_iter=self.epochs, verbose=False, random_state=0)
            self.rbms.append(rbm)

    def trainRBM(self,x):
        '''训练RBM层'''
        x = data2numpy(x)
        for rbm in self.rbms:
            rbm.fit(x)
            # 下一层的输入是该层的隐藏特征
            x = self.oneRbmForward(rbm,x)
        #对全连接层权重偏置赋值
        with torch.no_grad():
            for name, param in self.named_parameters():
                if "fc1.weight" in name:
                    param.copy_(torch.FloatTensor(self.rbms[0].components_))
                if "fc1.bias" in name:
                    param.copy_(torch.FloatTensor(self.rbms[0].intercept_hidden_))
                if "fc2.weight" in name:
                    param.copy_(torch.FloatTensor(self.rbms[1].components_))
                if "fc2.bias" in name:
                    param.copy_(torch.FloatTensor(self.rbms[1].intercept_hidden_))

    def oneRbmForward(self,rbm,x):
        '''计算一个rbm层的输出'''
        weight = rbm.components_
        baise = rbm.intercept_hidden_
        hidden = np.dot(x, weight.T) + baise
        return hidden

    def allRbmForward(self,x):
        '''所有RBM层前馈'''
        for rbm in self.rbms:
            x = self.oneRbmForward(rbm,x)
        x = torch.FloatTensor(x)
        x.to(device)
        return x

    def forward(self,x):
        x = self.fc1(x)
        x = self.relu1(x)
        x = self.fc2(x)
        x = self.relu2(x)
        x = self.fc3(x)
        return x

if __name__ == "__main__":
    middleDims = [6,11,1]
    x = torch.zeros((10, 5))
    dbn = DBN(inDim=5,middleDims=middleDims,epochs=10)

    dbn.trainRBM(x)
    # y = dbn(x)
    # print(y.shape)
